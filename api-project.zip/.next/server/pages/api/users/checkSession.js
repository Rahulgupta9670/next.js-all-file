"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/users/checkSession";
exports.ids = ["pages/api/users/checkSession"];
exports.modules = {

/***/ "jsonwebtoken":
/*!*******************************!*\
  !*** external "jsonwebtoken" ***!
  \*******************************/
/***/ ((module) => {

module.exports = require("jsonwebtoken");

/***/ }),

/***/ "mongoose":
/*!***************************!*\
  !*** external "mongoose" ***!
  \***************************/
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ "sessionstorage":
/*!*********************************!*\
  !*** external "sessionstorage" ***!
  \*********************************/
/***/ ((module) => {

module.exports = require("sessionstorage");

/***/ }),

/***/ "next-connect":
/*!*******************************!*\
  !*** external "next-connect" ***!
  \*******************************/
/***/ ((module) => {

module.exports = import("next-connect");;

/***/ }),

/***/ "(api)/./models/UserModels.js":
/*!******************************!*\
  !*** ./models/UserModels.js ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\nconst mongoose = __webpack_require__(/*! mongoose */ \"mongoose\");\nconst UserSchema = mongoose.Schema({\n    name: {\n        type: String\n    },\n    email: {\n        type: String\n    },\n    mobile: {\n        type: Number\n    }\n});\n// export default mongoose.models.User || mongoose.model(\"user\",userSchema);\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (mongoose.models.User || mongoose.model(\"User\", UserSchema));\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9tb2RlbHMvVXNlck1vZGVscy5qcy5qcyIsIm1hcHBpbmdzIjoiOzs7O0FBQUEsTUFBTUEsV0FBV0MsbUJBQU9BLENBQUMsMEJBQVU7QUFJbkMsTUFBTUMsYUFBYUYsU0FBU0csTUFBTSxDQUFDO0lBQy9CQyxNQUFLO1FBQ0RDLE1BQUtDO0lBRVQ7SUFDQUMsT0FBTTtRQUNGRixNQUFLQztJQUVUO0lBQ0NFLFFBQU87UUFDSkgsTUFBS0k7SUFFVDtBQUVKO0FBQ0EsNEVBQTRFO0FBQzVFLGlFQUFlVCxTQUFTVSxNQUFNLENBQUNDLElBQUksSUFBSVgsU0FBU1ksS0FBSyxDQUFDLFFBQVFWLFdBQVdBLEVBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9hcGktcHJvamVjdC8uL21vZGVscy9Vc2VyTW9kZWxzLmpzP2Q3ZmYiXSwic291cmNlc0NvbnRlbnQiOlsiY29uc3QgbW9uZ29vc2UgPSByZXF1aXJlKFwibW9uZ29vc2VcIik7XHJcblxyXG5cclxuXHJcbmNvbnN0IFVzZXJTY2hlbWEgPSBtb25nb29zZS5TY2hlbWEoe1xyXG4gICAgbmFtZTp7XHJcbiAgICAgICAgdHlwZTpTdHJpbmcsXHJcbiAgICAgICBcclxuICAgIH0sXHJcbiAgICBlbWFpbDp7XHJcbiAgICAgICAgdHlwZTpTdHJpbmcsXHJcbiAgICAgICBcclxuICAgIH0sXHJcbiAgICAgbW9iaWxlOntcclxuICAgICAgICB0eXBlOk51bWJlcixcclxuICAgICAgIFxyXG4gICAgfVxyXG4gICAgXHJcbn0pXHJcbi8vIGV4cG9ydCBkZWZhdWx0IG1vbmdvb3NlLm1vZGVscy5Vc2VyIHx8IG1vbmdvb3NlLm1vZGVsKFwidXNlclwiLHVzZXJTY2hlbWEpO1xyXG5leHBvcnQgZGVmYXVsdCBtb25nb29zZS5tb2RlbHMuVXNlciB8fCBtb25nb29zZS5tb2RlbChcIlVzZXJcIiwgVXNlclNjaGVtYSk7Il0sIm5hbWVzIjpbIm1vbmdvb3NlIiwicmVxdWlyZSIsIlVzZXJTY2hlbWEiLCJTY2hlbWEiLCJuYW1lIiwidHlwZSIsIlN0cmluZyIsImVtYWlsIiwibW9iaWxlIiwiTnVtYmVyIiwibW9kZWxzIiwiVXNlciIsIm1vZGVsIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(api)/./models/UserModels.js\n");

/***/ }),

/***/ "(api)/./pages/api/users/checkSession.js":
/*!*****************************************!*\
  !*** ./pages/api/users/checkSession.js ***!
  \*****************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var next_connect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next-connect */ \"next-connect\");\n/* harmony import */ var _models_UserModels__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../models/UserModels */ \"(api)/./models/UserModels.js\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([next_connect__WEBPACK_IMPORTED_MODULE_0__]);\nnext_connect__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n// const server = express();\n// server.use(express.json());\n\nconst dataBase = __webpack_require__(/*! ../../../utils/connectDb */ \"(api)/./utils/connectDb.js\");\nconst jwt = __webpack_require__(/*! jsonwebtoken */ \"jsonwebtoken\");\n\nvar sessionStorage = __webpack_require__(/*! sessionstorage */ \"sessionstorage\");\nconst checkSession = (0,next_connect__WEBPACK_IMPORTED_MODULE_0__[\"default\"])().post((req, res)=>{\n    let token = req.body.token;\n    console.log(\"token received\", token);\n    if (token != null && token != \"\") {\n        const item = jwt.verify(token, \"rahul\");\n        console.log(\"token,,,,,,,,,,,,,,,,,11\", token, item, item.user);\n        // res.json(data)\n        // if the item doesn't exist, return null\n        if (!item) {\n            res.json({\n                error: true,\n                errorMessage: \"No data found\"\n            });\n        }\n        return item.user;\n    } else {\n        console.log(\"in\");\n        res.json({\n            error: true,\n            errorMessage: \"Invalid Token\"\n        });\n    }\n    ;\n});\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (checkSession); //  const itemStr = sessionstorage.getItem(\"item_key\")\n // if the item doesn't exist, return null\n //    if (!itemStr) {\n //      return null\n //    }\n //    const items= JSON.parse(itemStr)\n //    const nows = new Date()\n //    // compare the expiry time of the item with the current time\n //    if (nows.getTime() > items.expiry) {\n //      // If the item is expired, delete the item from storage\n //      // and return null\n //     const datas= sessionstorage.removeItem(\"item_key\")\n //      console.log(\"timeeeeeeeeeeeeeeee\",datas )\n //      return null\n //    }\n //    res.status(200).json( {itemStr} )\n //    return item.value\n // }\n // export default handler\n // function setWithExpiry(key, value, ttl) {\n //   const now = new Date()\n //   // item is an object which contains the original value\n //   // as well as the time when it's supposed to expire\n //   const item = {\n //     value: value,\n //     expiry: now.getTime() + ttl,\n //   }\n //   localStorage.setItem(key, JSON.stringify(item))\n // }\n // function checkSession(key) {\n //   const itemStr = localStorage.getItem(key)\n //   // if the item doesn't exist, return null\n //   if (!itemStr) {\n //     return null\n //   }\n //   const item = JSON.parse(itemStr)\n //   const now = new Date()\n //   // compare the expiry time of the item with the current time\n //   if (now.getTime() > item.expiry) {\n //     // If the item is expired, delete the item from storage\n //     // and return null\n //     localStorage.removeItem(key)\n //     return null\n //   }\n //   else{\n //     return item.value\n //   }\n // }\n //  res.status(200).json( {data} )\n // function getWithExpiry(key) {\n //   const itemStr = localStorage.getItem(key)\n //   // if the item doesn't exist, return null\n //   if (!itemStr) {\n //     return null\n //   }\n //   const item = JSON.parse(itemStr)\n //   const now = new Date()\n //   // compare the expiry time of the item with the current time\n //   if (now.getTime() > item.expiry) {\n //     // If the item is expired, delete the item from storage\n //     // and return null\n //     localStorage.removeItem(key)\n //     return null\n //   }\n //   return item.value\n // }\n //   }\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9wYWdlcy9hcGkvdXNlcnMvY2hlY2tTZXNzaW9uLmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUNBLDRCQUE0QjtBQUM1Qiw4QkFBOEI7QUFDUztBQUN2QyxNQUFNQyxXQUFXQyxtQkFBT0EsQ0FBQyw0REFBMEI7QUFDbkQsTUFBTUMsTUFBTUQsbUJBQU9BLENBQUM7QUFDZ0M7QUFDcEQsSUFBSUcsaUJBQWlCSCxtQkFBT0EsQ0FBQyxzQ0FBZ0I7QUFFN0MsTUFBTUksZUFBZ0JOLHdEQUFXQSxHQUNoQ08sSUFBSSxDQUFDLENBQUNDLEtBQUlDLE1BQU87SUFDaEIsSUFBSUMsUUFBTUYsSUFBSUcsSUFBSSxDQUFDRCxLQUFLO0lBQ3hCRSxRQUFRQyxHQUFHLENBQUMsa0JBQWtCSDtJQUM5QixJQUFHQSxTQUFPLElBQUksSUFBSUEsU0FBTyxJQUFHO1FBQzFCLE1BQU1JLE9BQU9YLElBQUlZLE1BQU0sQ0FBQ0wsT0FBTTtRQUU5QkUsUUFBUUMsR0FBRyxDQUFDLDRCQUE0QkgsT0FBUUksTUFBS0EsS0FBS0UsSUFBSTtRQUM5RCxpQkFBaUI7UUFDakIseUNBQXlDO1FBQ3pDLElBQUksQ0FBQ0YsTUFBTTtZQUNUTCxJQUFJUSxJQUFJLENBQUM7Z0JBQUNDLE9BQU0sSUFBSTtnQkFBQ0MsY0FBYTtZQUFlO1FBQ25ELENBQUM7UUFDRCxPQUFPTCxLQUFLRSxJQUFJO0lBRWxCLE9BQ0k7UUFDRkosUUFBUUMsR0FBRyxDQUFDO1FBQ1pKLElBQUlRLElBQUksQ0FBQztZQUFDQyxPQUFNLElBQUk7WUFBQ0MsY0FBYTtRQUFlO0lBQ25ELENBQUM7O0FBSUg7QUFDQSxpRUFBZWIsWUFBWUEsRUFBQyxDQUl4QixzREFBc0Q7Q0FDckQseUNBQXlDO0NBQzVDLHFCQUFxQjtDQUNyQixtQkFBbUI7Q0FDbkIsT0FBTztDQUNQLHNDQUFzQztDQUN0Qyw2QkFBNkI7Q0FDN0Isa0VBQWtFO0NBQ2xFLDBDQUEwQztDQUMxQywrREFBK0Q7Q0FDL0QsMEJBQTBCO0NBQzFCLHlEQUF5RDtDQUN6RCxpREFBaUQ7Q0FDakQsbUJBQW1CO0NBQ25CLE9BQU87Q0FDUCx1Q0FBdUM7Q0FFdkMsdUJBQXVCO0NBRXZCLElBQUk7Q0FFSix5QkFBeUI7Q0FFM0IsNENBQTRDO0NBQzVDLDJCQUEyQjtDQUUzQiwyREFBMkQ7Q0FDM0Qsd0RBQXdEO0NBQ3hELG1CQUFtQjtDQUNuQixvQkFBb0I7Q0FDcEIsbUNBQW1DO0NBQ25DLE1BQU07Q0FDTixvREFBb0Q7Q0FDcEQsSUFBSTtDQUVKLCtCQUErQjtDQUMvQiw4Q0FBOEM7Q0FDOUMsOENBQThDO0NBQzlDLG9CQUFvQjtDQUNwQixrQkFBa0I7Q0FDbEIsTUFBTTtDQUNOLHFDQUFxQztDQUNyQywyQkFBMkI7Q0FDM0IsaUVBQWlFO0NBQ2pFLHVDQUF1QztDQUN2Qyw4REFBOEQ7Q0FDOUQseUJBQXlCO0NBQ3pCLG1DQUFtQztDQUNuQyxrQkFBa0I7Q0FDbEIsTUFBTTtDQUNOLFVBQVU7Q0FDVix3QkFBd0I7Q0FDeEIsTUFBTTtDQUVOLElBQUk7Q0FDQSxrQ0FBa0M7Q0FFcEMsZ0NBQWdDO0NBQ2hDLDhDQUE4QztDQUM5Qyw4Q0FBOEM7Q0FDOUMsb0JBQW9CO0NBQ3BCLGtCQUFrQjtDQUNsQixNQUFNO0NBQ04scUNBQXFDO0NBQ3JDLDJCQUEyQjtDQUMzQixpRUFBaUU7Q0FDakUsdUNBQXVDO0NBQ3ZDLDhEQUE4RDtDQUM5RCx5QkFBeUI7Q0FDekIsbUNBQW1DO0NBQ25DLGtCQUFrQjtDQUNsQixNQUFNO0NBQ04sc0JBQXNCO0NBQ3RCLElBQUk7Q0FHTixNQUFNIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vYXBpLXByb2plY3QvLi9wYWdlcy9hcGkvdXNlcnMvY2hlY2tTZXNzaW9uLmpzPzgyMWEiXSwic291cmNlc0NvbnRlbnQiOlsiXHJcbi8vIGNvbnN0IHNlcnZlciA9IGV4cHJlc3MoKTtcclxuLy8gc2VydmVyLnVzZShleHByZXNzLmpzb24oKSk7XHJcbmltcG9ydCBuZXh0Q29ubmVjdCBmcm9tIFwibmV4dC1jb25uZWN0XCI7XHJcbmNvbnN0IGRhdGFCYXNlID0gcmVxdWlyZShcIi4uLy4uLy4uL3V0aWxzL2Nvbm5lY3REYlwiKTtcclxuY29uc3Qgand0ID0gcmVxdWlyZSgnanNvbndlYnRva2VuJyk7XHJcbmltcG9ydCBVc2VyTW9kZWxzIGZyb20gXCIuLi8uLi8uLi9tb2RlbHMvVXNlck1vZGVsc1wiO1xyXG52YXIgc2Vzc2lvblN0b3JhZ2UgPSByZXF1aXJlKFwic2Vzc2lvbnN0b3JhZ2VcIilcclxuXHJcbmNvbnN0IGNoZWNrU2Vzc2lvbiAgPSBuZXh0Q29ubmVjdCgpXHJcbi5wb3N0KChyZXEscmVzKSA9PntcclxuICBsZXQgdG9rZW49cmVxLmJvZHkudG9rZW47XHJcbiAgY29uc29sZS5sb2coXCJ0b2tlbiByZWNlaXZlZFwiLCB0b2tlbilcclxuICBpZih0b2tlbiE9bnVsbCAmJiB0b2tlbiE9Jycpe1xyXG4gICAgY29uc3QgaXRlbSA9IGp3dC52ZXJpZnkodG9rZW4sXCJyYWh1bFwiKTtcclxuICAgIFxyXG4gICAgY29uc29sZS5sb2coXCJ0b2tlbiwsLCwsLCwsLCwsLCwsLCwsMTFcIiwgdG9rZW4gLCBpdGVtLGl0ZW0udXNlcilcclxuICAgIC8vIHJlcy5qc29uKGRhdGEpXHJcbiAgICAvLyBpZiB0aGUgaXRlbSBkb2Vzbid0IGV4aXN0LCByZXR1cm4gbnVsbFxyXG4gICAgaWYgKCFpdGVtKSB7XHJcbiAgICAgIHJlcy5qc29uKHtlcnJvcjp0cnVlLGVycm9yTWVzc2FnZTonTm8gZGF0YSBmb3VuZCd9KVxyXG4gICAgfVxyXG4gICAgcmV0dXJuIGl0ZW0udXNlcjtcclxuICAgIFxyXG4gIH1cclxuICBlbHNle1xyXG4gICAgY29uc29sZS5sb2coXCJpblwiKVxyXG4gICAgcmVzLmpzb24oe2Vycm9yOnRydWUsZXJyb3JNZXNzYWdlOidJbnZhbGlkIFRva2VuJ30pXHJcbiAgfTtcclxuICBcclxuICBcclxuICAgXHJcbn0pO1xyXG5leHBvcnQgZGVmYXVsdCBjaGVja1Nlc3Npb247XHJcblxyXG4gICAgXHJcblxyXG4gICAgLy8gIGNvbnN0IGl0ZW1TdHIgPSBzZXNzaW9uc3RvcmFnZS5nZXRJdGVtKFwiaXRlbV9rZXlcIilcclxuICAgICAvLyBpZiB0aGUgaXRlbSBkb2Vzbid0IGV4aXN0LCByZXR1cm4gbnVsbFxyXG4gIC8vICAgIGlmICghaXRlbVN0cikge1xyXG4gIC8vICAgICAgcmV0dXJuIG51bGxcclxuICAvLyAgICB9XHJcbiAgLy8gICAgY29uc3QgaXRlbXM9IEpTT04ucGFyc2UoaXRlbVN0cilcclxuICAvLyAgICBjb25zdCBub3dzID0gbmV3IERhdGUoKVxyXG4gIC8vICAgIC8vIGNvbXBhcmUgdGhlIGV4cGlyeSB0aW1lIG9mIHRoZSBpdGVtIHdpdGggdGhlIGN1cnJlbnQgdGltZVxyXG4gIC8vICAgIGlmIChub3dzLmdldFRpbWUoKSA+IGl0ZW1zLmV4cGlyeSkge1xyXG4gIC8vICAgICAgLy8gSWYgdGhlIGl0ZW0gaXMgZXhwaXJlZCwgZGVsZXRlIHRoZSBpdGVtIGZyb20gc3RvcmFnZVxyXG4gIC8vICAgICAgLy8gYW5kIHJldHVybiBudWxsXHJcbiAgLy8gICAgIGNvbnN0IGRhdGFzPSBzZXNzaW9uc3RvcmFnZS5yZW1vdmVJdGVtKFwiaXRlbV9rZXlcIilcclxuICAvLyAgICAgIGNvbnNvbGUubG9nKFwidGltZWVlZWVlZWVlZWVlZWVlZVwiLGRhdGFzIClcclxuICAvLyAgICAgIHJldHVybiBudWxsXHJcbiAgLy8gICAgfVxyXG4gIC8vICAgIHJlcy5zdGF0dXMoMjAwKS5qc29uKCB7aXRlbVN0cn0gKVxyXG4gICAgIFxyXG4gIC8vICAgIHJldHVybiBpdGVtLnZhbHVlXHJcbiAgICAgXHJcbiAgLy8gfVxyXG5cclxuICAvLyBleHBvcnQgZGVmYXVsdCBoYW5kbGVyXHJcblxyXG4vLyBmdW5jdGlvbiBzZXRXaXRoRXhwaXJ5KGtleSwgdmFsdWUsIHR0bCkge1xyXG4vLyAgIGNvbnN0IG5vdyA9IG5ldyBEYXRlKClcclxuXHJcbi8vICAgLy8gaXRlbSBpcyBhbiBvYmplY3Qgd2hpY2ggY29udGFpbnMgdGhlIG9yaWdpbmFsIHZhbHVlXHJcbi8vICAgLy8gYXMgd2VsbCBhcyB0aGUgdGltZSB3aGVuIGl0J3Mgc3VwcG9zZWQgdG8gZXhwaXJlXHJcbi8vICAgY29uc3QgaXRlbSA9IHtcclxuLy8gICAgIHZhbHVlOiB2YWx1ZSxcclxuLy8gICAgIGV4cGlyeTogbm93LmdldFRpbWUoKSArIHR0bCxcclxuLy8gICB9XHJcbi8vICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oa2V5LCBKU09OLnN0cmluZ2lmeShpdGVtKSlcclxuLy8gfVxyXG5cclxuLy8gZnVuY3Rpb24gY2hlY2tTZXNzaW9uKGtleSkge1xyXG4vLyAgIGNvbnN0IGl0ZW1TdHIgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShrZXkpXHJcbi8vICAgLy8gaWYgdGhlIGl0ZW0gZG9lc24ndCBleGlzdCwgcmV0dXJuIG51bGxcclxuLy8gICBpZiAoIWl0ZW1TdHIpIHtcclxuLy8gICAgIHJldHVybiBudWxsXHJcbi8vICAgfVxyXG4vLyAgIGNvbnN0IGl0ZW0gPSBKU09OLnBhcnNlKGl0ZW1TdHIpXHJcbi8vICAgY29uc3Qgbm93ID0gbmV3IERhdGUoKVxyXG4vLyAgIC8vIGNvbXBhcmUgdGhlIGV4cGlyeSB0aW1lIG9mIHRoZSBpdGVtIHdpdGggdGhlIGN1cnJlbnQgdGltZVxyXG4vLyAgIGlmIChub3cuZ2V0VGltZSgpID4gaXRlbS5leHBpcnkpIHtcclxuLy8gICAgIC8vIElmIHRoZSBpdGVtIGlzIGV4cGlyZWQsIGRlbGV0ZSB0aGUgaXRlbSBmcm9tIHN0b3JhZ2VcclxuLy8gICAgIC8vIGFuZCByZXR1cm4gbnVsbFxyXG4vLyAgICAgbG9jYWxTdG9yYWdlLnJlbW92ZUl0ZW0oa2V5KVxyXG4vLyAgICAgcmV0dXJuIG51bGxcclxuLy8gICB9XHJcbi8vICAgZWxzZXtcclxuLy8gICAgIHJldHVybiBpdGVtLnZhbHVlXHJcbi8vICAgfVxyXG4gIFxyXG4vLyB9XHJcbiAgICAvLyAgcmVzLnN0YXR1cygyMDApLmpzb24oIHtkYXRhfSApXHJcblxyXG4gIC8vIGZ1bmN0aW9uIGdldFdpdGhFeHBpcnkoa2V5KSB7XHJcbiAgLy8gICBjb25zdCBpdGVtU3RyID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oa2V5KVxyXG4gIC8vICAgLy8gaWYgdGhlIGl0ZW0gZG9lc24ndCBleGlzdCwgcmV0dXJuIG51bGxcclxuICAvLyAgIGlmICghaXRlbVN0cikge1xyXG4gIC8vICAgICByZXR1cm4gbnVsbFxyXG4gIC8vICAgfVxyXG4gIC8vICAgY29uc3QgaXRlbSA9IEpTT04ucGFyc2UoaXRlbVN0cilcclxuICAvLyAgIGNvbnN0IG5vdyA9IG5ldyBEYXRlKClcclxuICAvLyAgIC8vIGNvbXBhcmUgdGhlIGV4cGlyeSB0aW1lIG9mIHRoZSBpdGVtIHdpdGggdGhlIGN1cnJlbnQgdGltZVxyXG4gIC8vICAgaWYgKG5vdy5nZXRUaW1lKCkgPiBpdGVtLmV4cGlyeSkge1xyXG4gIC8vICAgICAvLyBJZiB0aGUgaXRlbSBpcyBleHBpcmVkLCBkZWxldGUgdGhlIGl0ZW0gZnJvbSBzdG9yYWdlXHJcbiAgLy8gICAgIC8vIGFuZCByZXR1cm4gbnVsbFxyXG4gIC8vICAgICBsb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbShrZXkpXHJcbiAgLy8gICAgIHJldHVybiBudWxsXHJcbiAgLy8gICB9XHJcbiAgLy8gICByZXR1cm4gaXRlbS52YWx1ZVxyXG4gIC8vIH1cclxuXHJcbiAgIFxyXG4vLyAgIH1cclxuXHJcblxyXG4iXSwibmFtZXMiOlsibmV4dENvbm5lY3QiLCJkYXRhQmFzZSIsInJlcXVpcmUiLCJqd3QiLCJVc2VyTW9kZWxzIiwic2Vzc2lvblN0b3JhZ2UiLCJjaGVja1Nlc3Npb24iLCJwb3N0IiwicmVxIiwicmVzIiwidG9rZW4iLCJib2R5IiwiY29uc29sZSIsImxvZyIsIml0ZW0iLCJ2ZXJpZnkiLCJ1c2VyIiwianNvbiIsImVycm9yIiwiZXJyb3JNZXNzYWdlIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(api)/./pages/api/users/checkSession.js\n");

/***/ }),

/***/ "(api)/./utils/connectDb.js":
/*!****************************!*\
  !*** ./utils/connectDb.js ***!
  \****************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

eval("\nconst mongoose = __webpack_require__(/*! mongoose */ \"mongoose\");\nasync function connectDb() {\n    try {\n        const Mongo_URI = \"mongodb://localhost:27017/nextjsdb\";\n        await mongoose.connect(Mongo_URI, {\n            useUnifiedTopology: true,\n            useNewUrlParser: true\n        });\n        console.log(\"connect to Mogodb localhost\");\n    } catch (error) {\n        console.log(error);\n    }\n}\nmodule.exports = connectDb;\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi91dGlscy9jb25uZWN0RGIuanMuanMiLCJtYXBwaW5ncyI6IkFBQUE7QUFBQSxNQUFNQSxXQUFXQyxtQkFBT0EsQ0FBQywwQkFBVTtBQUVuQyxlQUFlQyxZQUFXO0lBQ3RCLElBQUk7UUFDQSxNQUFNQyxZQUFZO1FBQ2xCLE1BQU1ILFNBQVNJLE9BQU8sQ0FBQ0QsV0FBVTtZQUM3QkUsb0JBQW1CLElBQUk7WUFDdkJDLGlCQUFnQixJQUFJO1FBQ3hCO1FBQ0FDLFFBQVFDLEdBQUcsQ0FBQztJQUVoQixFQUFFLE9BQU9DLE9BQU87UUFFWkYsUUFBUUMsR0FBRyxDQUFDQztJQUVoQjtBQUNKO0FBQ0FDLE9BQU9DLE9BQU8sR0FBR1QiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9hcGktcHJvamVjdC8uL3V0aWxzL2Nvbm5lY3REYi5qcz85NWUxIl0sInNvdXJjZXNDb250ZW50IjpbImNvbnN0IG1vbmdvb3NlID0gcmVxdWlyZShcIm1vbmdvb3NlXCIpO1xyXG5cclxuYXN5bmMgZnVuY3Rpb24gY29ubmVjdERiKCl7XHJcbiAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IE1vbmdvX1VSSSA9IFwibW9uZ29kYjovL2xvY2FsaG9zdDoyNzAxNy9uZXh0anNkYlwiO1xyXG4gICAgICAgIGF3YWl0IG1vbmdvb3NlLmNvbm5lY3QoTW9uZ29fVVJJLHtcclxuICAgICAgICAgICAgdXNlVW5pZmllZFRvcG9sb2d5OnRydWUsXHJcbiAgICAgICAgICAgIHVzZU5ld1VybFBhcnNlcjp0cnVlLFxyXG4gICAgICAgIH0pXHJcbiAgICAgICAgY29uc29sZS5sb2coXCJjb25uZWN0IHRvIE1vZ29kYiBsb2NhbGhvc3RcIilcclxuXHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICBcclxuICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgXHJcbiAgICB9XHJcbn1cclxubW9kdWxlLmV4cG9ydHMgPSBjb25uZWN0RGI7Il0sIm5hbWVzIjpbIm1vbmdvb3NlIiwicmVxdWlyZSIsImNvbm5lY3REYiIsIk1vbmdvX1VSSSIsImNvbm5lY3QiLCJ1c2VVbmlmaWVkVG9wb2xvZ3kiLCJ1c2VOZXdVcmxQYXJzZXIiLCJjb25zb2xlIiwibG9nIiwiZXJyb3IiLCJtb2R1bGUiLCJleHBvcnRzIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(api)/./utils/connectDb.js\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("(api)/./pages/api/users/checkSession.js"));
module.exports = __webpack_exports__;

})();