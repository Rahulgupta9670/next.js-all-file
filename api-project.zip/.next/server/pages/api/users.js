"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/users";
exports.ids = ["pages/api/users"];
exports.modules = {

/***/ "jsonwebtoken":
/*!*******************************!*\
  !*** external "jsonwebtoken" ***!
  \*******************************/
/***/ ((module) => {

module.exports = require("jsonwebtoken");

/***/ }),

/***/ "mongoose":
/*!***************************!*\
  !*** external "mongoose" ***!
  \***************************/
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ "next-connect":
/*!*******************************!*\
  !*** external "next-connect" ***!
  \*******************************/
/***/ ((module) => {

module.exports = import("next-connect");;

/***/ }),

/***/ "(api)/./models/UserModels.js":
/*!******************************!*\
  !*** ./models/UserModels.js ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\nconst mongoose = __webpack_require__(/*! mongoose */ \"mongoose\");\nconst UserSchema = mongoose.Schema({\n    name: {\n        type: String\n    },\n    email: {\n        type: String\n    },\n    mobile: {\n        type: Number\n    }\n});\n// export default mongoose.models.User || mongoose.model(\"user\",userSchema);\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (mongoose.models.User || mongoose.model(\"User\", UserSchema));\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9tb2RlbHMvVXNlck1vZGVscy5qcy5qcyIsIm1hcHBpbmdzIjoiOzs7O0FBQUEsTUFBTUEsV0FBV0MsbUJBQU9BLENBQUMsMEJBQVU7QUFJbkMsTUFBTUMsYUFBYUYsU0FBU0csTUFBTSxDQUFDO0lBQy9CQyxNQUFLO1FBQ0RDLE1BQUtDO0lBRVQ7SUFDQUMsT0FBTTtRQUNGRixNQUFLQztJQUVUO0lBQ0NFLFFBQU87UUFDSkgsTUFBS0k7SUFFVDtBQUVKO0FBQ0EsNEVBQTRFO0FBQzVFLGlFQUFlVCxTQUFTVSxNQUFNLENBQUNDLElBQUksSUFBSVgsU0FBU1ksS0FBSyxDQUFDLFFBQVFWLFdBQVdBLEVBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9hcGktcHJvamVjdC8uL21vZGVscy9Vc2VyTW9kZWxzLmpzP2Q3ZmYiXSwic291cmNlc0NvbnRlbnQiOlsiY29uc3QgbW9uZ29vc2UgPSByZXF1aXJlKFwibW9uZ29vc2VcIik7XHJcblxyXG5cclxuXHJcbmNvbnN0IFVzZXJTY2hlbWEgPSBtb25nb29zZS5TY2hlbWEoe1xyXG4gICAgbmFtZTp7XHJcbiAgICAgICAgdHlwZTpTdHJpbmcsXHJcbiAgICAgICBcclxuICAgIH0sXHJcbiAgICBlbWFpbDp7XHJcbiAgICAgICAgdHlwZTpTdHJpbmcsXHJcbiAgICAgICBcclxuICAgIH0sXHJcbiAgICAgbW9iaWxlOntcclxuICAgICAgICB0eXBlOk51bWJlcixcclxuICAgICAgIFxyXG4gICAgfVxyXG4gICAgXHJcbn0pXHJcbi8vIGV4cG9ydCBkZWZhdWx0IG1vbmdvb3NlLm1vZGVscy5Vc2VyIHx8IG1vbmdvb3NlLm1vZGVsKFwidXNlclwiLHVzZXJTY2hlbWEpO1xyXG5leHBvcnQgZGVmYXVsdCBtb25nb29zZS5tb2RlbHMuVXNlciB8fCBtb25nb29zZS5tb2RlbChcIlVzZXJcIiwgVXNlclNjaGVtYSk7Il0sIm5hbWVzIjpbIm1vbmdvb3NlIiwicmVxdWlyZSIsIlVzZXJTY2hlbWEiLCJTY2hlbWEiLCJuYW1lIiwidHlwZSIsIlN0cmluZyIsImVtYWlsIiwibW9iaWxlIiwiTnVtYmVyIiwibW9kZWxzIiwiVXNlciIsIm1vZGVsIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(api)/./models/UserModels.js\n");

/***/ }),

/***/ "(api)/./pages/api/users/index.js":
/*!**********************************!*\
  !*** ./pages/api/users/index.js ***!
  \**********************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var next_connect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next-connect */ \"next-connect\");\n/* harmony import */ var _models_UserModels__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../models/UserModels */ \"(api)/./models/UserModels.js\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([next_connect__WEBPACK_IMPORTED_MODULE_0__]);\nnext_connect__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\n\nconst dataBase = __webpack_require__(/*! ../../../utils/connectDb */ \"(api)/./utils/connectDb.js\");\nconst jwt = __webpack_require__(/*! jsonwebtoken */ \"jsonwebtoken\");\ndataBase();\nconst handler = (0,next_connect__WEBPACK_IMPORTED_MODULE_0__[\"default\"])()// app.use('/login', (req, res) => {\n//   res.send({\n//     token: 'test123'\n//   });\n// }\n//  response to GET\n.get(async (req, res)=>{\n    try {\n        const users = await _models_UserModels__WEBPACK_IMPORTED_MODULE_1__[\"default\"].find({});\n        res.send(users);\n    } catch (error) {\n        console.log(error);\n    }\n    res.send(\"rahul; gupta\");\n})//   try {\n//     let users\n//     if(req.query.id){\n//        users = await UserModels.find({_id:req.query.id});\n//     }else{\n//        users = await UserModels.find({});\n//     }\n//     res.send(users);\n//   } catch (error) {\n//     console.log(error);\n//   }\n//   res.send(\"rahul; gupta\");\n// })\n//  response to POST\n.post(async (req, res)=>{\n    const { name , email , mobile  } = req.body;\n    const newIUser = new _models_UserModels__WEBPACK_IMPORTED_MODULE_1__[\"default\"]({\n        name,\n        email,\n        mobile\n    });\n    // const data = \n    console.log(\"newuserrrrr............\", newIUser);\n    const newIUsers = {\n        name,\n        email,\n        mobile\n    };\n    // const token = jwt.sign(data, \"rahul\", { \"expiresIn\": 600 });\n    try {\n        await newIUser.save();\n        const token = jwt.sign(newIUsers, \"rahul\", {\n            \"expiresIn\": 600\n        });\n        res.json({\n            token\n        });\n        console.log(\"tokenrahul12............\", token);\n    } catch (error) {\n        console.log(error);\n    }\n    res.send(newIUser);\n// res.json({ token })\n});\n//  export using handler.export()\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (handler);\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9wYWdlcy9hcGkvdXNlcnMvaW5kZXguanMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQXVDO0FBQ2E7QUFDcEQsTUFBTUUsV0FBV0MsbUJBQU9BLENBQUMsNERBQTBCO0FBQ25ELE1BQU1DLE1BQU1ELG1CQUFPQSxDQUFDO0FBR3BCRDtBQUNBLE1BQU1HLFVBQVVMLHdEQUFXQSxFQUUzQixvQ0FBb0M7QUFFcEMsZUFBZTtBQUVmLHVCQUF1QjtBQUV2QixRQUFRO0FBQ1IsSUFBSTtBQUVGLG1CQUFtQjtDQUNsQk0sR0FBRyxDQUFDLE9BQU9DLEtBQUtDLE1BQVE7SUFDdkIsSUFBSTtRQUNGLE1BQU1DLFFBQVEsTUFBTVIsK0RBQWUsQ0FBQyxDQUFDO1FBQ3JDTyxJQUFJRyxJQUFJLENBQUNGO0lBQ1gsRUFBRSxPQUFPRyxPQUFPO1FBQ2RDLFFBQVFDLEdBQUcsQ0FBQ0Y7SUFDZDtJQUNBSixJQUFJRyxJQUFJLENBQUM7QUFDWCxFQUNBLFVBQVU7QUFDVixnQkFBZ0I7QUFDaEIsd0JBQXdCO0FBQ3hCLDREQUE0RDtBQUM1RCxhQUFhO0FBQ2IsNENBQTRDO0FBQzVDLFFBQVE7QUFFUix1QkFBdUI7QUFDdkIsc0JBQXNCO0FBQ3RCLDBCQUEwQjtBQUMxQixNQUFNO0FBQ04sOEJBQThCO0FBQzlCLEtBQUs7QUFFTCxvQkFBb0I7Q0FDbkJJLElBQUksQ0FBQyxPQUFPUixLQUFLQyxNQUFRO0lBQ3hCLE1BQU0sRUFBRVEsS0FBSSxFQUFFQyxNQUFLLEVBQUVDLE9BQU0sRUFBRSxHQUFHWCxJQUFJWSxJQUFJO0lBQ3hDLE1BQU1DLFdBQVcsSUFBSW5CLDBEQUFVQSxDQUFDO1FBQUVlO1FBQU1DO1FBQU9DO0lBQU87SUFDdEQsZ0JBQWdCO0lBQ2hCTCxRQUFRQyxHQUFHLENBQUMsMkJBQTBCTTtJQUN0QyxNQUFNQyxZQUFZO1FBQ2hCTDtRQUNBQztRQUNBQztJQUNGO0lBRUEsK0RBQStEO0lBQy9ELElBQUk7UUFDRixNQUFNRSxTQUFTRSxJQUFJO1FBQ25CLE1BQU1DLFFBQVFuQixJQUFJb0IsSUFBSSxDQUFDSCxXQUFXLFNBQVM7WUFBRSxhQUFhO1FBQUk7UUFFOURiLElBQUlpQixJQUFJLENBQUM7WUFBRUY7UUFBTTtRQUNqQlYsUUFBUUMsR0FBRyxDQUFDLDRCQUEyQlM7SUFFekMsRUFBRSxPQUFPWCxPQUFPO1FBQ2RDLFFBQVFDLEdBQUcsQ0FBQ0Y7SUFDZDtJQUNBSixJQUFJRyxJQUFJLENBQUNTO0FBQ1Qsc0JBQXNCO0FBQ3hCO0FBRUYsaUNBQWlDO0FBQ2pDLGlFQUFlZixPQUFPQSxFQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vYXBpLXByb2plY3QvLi9wYWdlcy9hcGkvdXNlcnMvaW5kZXguanM/MWQ4YiJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgbmV4dENvbm5lY3QgZnJvbSBcIm5leHQtY29ubmVjdFwiO1xyXG5pbXBvcnQgVXNlck1vZGVscyBmcm9tIFwiLi4vLi4vLi4vbW9kZWxzL1VzZXJNb2RlbHNcIjtcclxuY29uc3QgZGF0YUJhc2UgPSByZXF1aXJlKFwiLi4vLi4vLi4vdXRpbHMvY29ubmVjdERiXCIpO1xyXG5jb25zdCBqd3QgPSByZXF1aXJlKCdqc29ud2VidG9rZW4nKTtcclxuXHJcblxyXG5kYXRhQmFzZSgpO1xyXG5jb25zdCBoYW5kbGVyID0gbmV4dENvbm5lY3QoKVxyXG5cclxuLy8gYXBwLnVzZSgnL2xvZ2luJywgKHJlcSwgcmVzKSA9PiB7XHJcblxyXG4vLyAgIHJlcy5zZW5kKHtcclxuXHJcbi8vICAgICB0b2tlbjogJ3Rlc3QxMjMnXHJcblxyXG4vLyAgIH0pO1xyXG4vLyB9XHJcblxyXG4gIC8vICByZXNwb25zZSB0byBHRVRcclxuICAuZ2V0KGFzeW5jIChyZXEsIHJlcykgPT4ge1xyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgdXNlcnMgPSBhd2FpdCBVc2VyTW9kZWxzLmZpbmQoe30pO1xyXG4gICAgICByZXMuc2VuZCh1c2Vycyk7XHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICB9XHJcbiAgICByZXMuc2VuZChcInJhaHVsOyBndXB0YVwiKTtcclxuICB9KVxyXG4gIC8vICAgdHJ5IHtcclxuICAvLyAgICAgbGV0IHVzZXJzXHJcbiAgLy8gICAgIGlmKHJlcS5xdWVyeS5pZCl7XHJcbiAgLy8gICAgICAgIHVzZXJzID0gYXdhaXQgVXNlck1vZGVscy5maW5kKHtfaWQ6cmVxLnF1ZXJ5LmlkfSk7XHJcbiAgLy8gICAgIH1lbHNle1xyXG4gIC8vICAgICAgICB1c2VycyA9IGF3YWl0IFVzZXJNb2RlbHMuZmluZCh7fSk7XHJcbiAgLy8gICAgIH1cclxuXHJcbiAgLy8gICAgIHJlcy5zZW5kKHVzZXJzKTtcclxuICAvLyAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgLy8gICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAvLyAgIH1cclxuICAvLyAgIHJlcy5zZW5kKFwicmFodWw7IGd1cHRhXCIpO1xyXG4gIC8vIH0pXHJcblxyXG4gIC8vICByZXNwb25zZSB0byBQT1NUXHJcbiAgLnBvc3QoYXN5bmMgKHJlcSwgcmVzKSA9PiB7XHJcbiAgICBjb25zdCB7IG5hbWUsIGVtYWlsLCBtb2JpbGUgfSA9IHJlcS5ib2R5O1xyXG4gICAgY29uc3QgbmV3SVVzZXIgPSBuZXcgVXNlck1vZGVscyh7IG5hbWUsIGVtYWlsLCBtb2JpbGUgfSk7XHJcbiAgICAvLyBjb25zdCBkYXRhID0gXHJcbiAgICBjb25zb2xlLmxvZyhcIm5ld3VzZXJycnJyLi4uLi4uLi4uLi4uXCIsbmV3SVVzZXIpXHJcbiAgICBjb25zdCBuZXdJVXNlcnMgPSB7XHJcbiAgICAgIG5hbWUsXHJcbiAgICAgIGVtYWlsLCBcclxuICAgICAgbW9iaWxlXHJcbiAgICB9XHJcbiAgIFxyXG4gICAgLy8gY29uc3QgdG9rZW4gPSBqd3Quc2lnbihkYXRhLCBcInJhaHVsXCIsIHsgXCJleHBpcmVzSW5cIjogNjAwIH0pO1xyXG4gICAgdHJ5IHtcclxuICAgICAgYXdhaXQgbmV3SVVzZXIuc2F2ZSgpO1xyXG4gICAgICBjb25zdCB0b2tlbiA9IGp3dC5zaWduKG5ld0lVc2VycywgXCJyYWh1bFwiLCB7IFwiZXhwaXJlc0luXCI6IDYwMCB9KTtcclxuICAgICBcclxuICAgICAgcmVzLmpzb24oeyB0b2tlbiB9KVxyXG4gICAgICBjb25zb2xlLmxvZyhcInRva2VucmFodWwxMi4uLi4uLi4uLi4uLlwiLHRva2VuKVxyXG5cclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcclxuICAgIH1cclxuICAgIHJlcy5zZW5kKG5ld0lVc2VyLCApO1xyXG4gICAgLy8gcmVzLmpzb24oeyB0b2tlbiB9KVxyXG4gIH0pO1xyXG5cclxuLy8gIGV4cG9ydCB1c2luZyBoYW5kbGVyLmV4cG9ydCgpXHJcbmV4cG9ydCBkZWZhdWx0IGhhbmRsZXI7XHJcbiJdLCJuYW1lcyI6WyJuZXh0Q29ubmVjdCIsIlVzZXJNb2RlbHMiLCJkYXRhQmFzZSIsInJlcXVpcmUiLCJqd3QiLCJoYW5kbGVyIiwiZ2V0IiwicmVxIiwicmVzIiwidXNlcnMiLCJmaW5kIiwic2VuZCIsImVycm9yIiwiY29uc29sZSIsImxvZyIsInBvc3QiLCJuYW1lIiwiZW1haWwiLCJtb2JpbGUiLCJib2R5IiwibmV3SVVzZXIiLCJuZXdJVXNlcnMiLCJzYXZlIiwidG9rZW4iLCJzaWduIiwianNvbiJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(api)/./pages/api/users/index.js\n");

/***/ }),

/***/ "(api)/./utils/connectDb.js":
/*!****************************!*\
  !*** ./utils/connectDb.js ***!
  \****************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

eval("\nconst mongoose = __webpack_require__(/*! mongoose */ \"mongoose\");\nasync function connectDb() {\n    try {\n        const Mongo_URI = \"mongodb://localhost:27017/nextjsdb\";\n        await mongoose.connect(Mongo_URI, {\n            useUnifiedTopology: true,\n            useNewUrlParser: true\n        });\n        console.log(\"connect to Mogodb localhost\");\n    } catch (error) {\n        console.log(error);\n    }\n}\nmodule.exports = connectDb;\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi91dGlscy9jb25uZWN0RGIuanMuanMiLCJtYXBwaW5ncyI6IkFBQUE7QUFBQSxNQUFNQSxXQUFXQyxtQkFBT0EsQ0FBQywwQkFBVTtBQUVuQyxlQUFlQyxZQUFXO0lBQ3RCLElBQUk7UUFDQSxNQUFNQyxZQUFZO1FBQ2xCLE1BQU1ILFNBQVNJLE9BQU8sQ0FBQ0QsV0FBVTtZQUM3QkUsb0JBQW1CLElBQUk7WUFDdkJDLGlCQUFnQixJQUFJO1FBQ3hCO1FBQ0FDLFFBQVFDLEdBQUcsQ0FBQztJQUVoQixFQUFFLE9BQU9DLE9BQU87UUFFWkYsUUFBUUMsR0FBRyxDQUFDQztJQUVoQjtBQUNKO0FBQ0FDLE9BQU9DLE9BQU8sR0FBR1QiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9hcGktcHJvamVjdC8uL3V0aWxzL2Nvbm5lY3REYi5qcz85NWUxIl0sInNvdXJjZXNDb250ZW50IjpbImNvbnN0IG1vbmdvb3NlID0gcmVxdWlyZShcIm1vbmdvb3NlXCIpO1xyXG5cclxuYXN5bmMgZnVuY3Rpb24gY29ubmVjdERiKCl7XHJcbiAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IE1vbmdvX1VSSSA9IFwibW9uZ29kYjovL2xvY2FsaG9zdDoyNzAxNy9uZXh0anNkYlwiO1xyXG4gICAgICAgIGF3YWl0IG1vbmdvb3NlLmNvbm5lY3QoTW9uZ29fVVJJLHtcclxuICAgICAgICAgICAgdXNlVW5pZmllZFRvcG9sb2d5OnRydWUsXHJcbiAgICAgICAgICAgIHVzZU5ld1VybFBhcnNlcjp0cnVlLFxyXG4gICAgICAgIH0pXHJcbiAgICAgICAgY29uc29sZS5sb2coXCJjb25uZWN0IHRvIE1vZ29kYiBsb2NhbGhvc3RcIilcclxuXHJcbiAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICBcclxuICAgICAgICBjb25zb2xlLmxvZyhlcnJvcik7XHJcbiAgICAgICAgXHJcbiAgICB9XHJcbn1cclxubW9kdWxlLmV4cG9ydHMgPSBjb25uZWN0RGI7Il0sIm5hbWVzIjpbIm1vbmdvb3NlIiwicmVxdWlyZSIsImNvbm5lY3REYiIsIk1vbmdvX1VSSSIsImNvbm5lY3QiLCJ1c2VVbmlmaWVkVG9wb2xvZ3kiLCJ1c2VOZXdVcmxQYXJzZXIiLCJjb25zb2xlIiwibG9nIiwiZXJyb3IiLCJtb2R1bGUiLCJleHBvcnRzIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(api)/./utils/connectDb.js\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("(api)/./pages/api/users/index.js"));
module.exports = __webpack_exports__;

})();