/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "./pages/_app.js":
/*!***********************!*\
  !*** ./pages/_app.js ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next-auth/react */ \"next-auth/react\");\n/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../styles/globals.css */ \"./styles/globals.css\");\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! next/router */ \"next/router\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);\n\n\n\n\n\n\n\nfunction MyApp({ Component , pageProps  }) {\n    const [user, setUser] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(null);\n    const [authorized, setAuthorized] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);\n    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{\n        // on initial load - run auth check\n        authCheck((next_router__WEBPACK_IMPORTED_MODULE_4___default().asPath));\n        // on route change start - hide page content by setting authorized to false\n        const hideContent = ()=>setAuthorized(false);\n        next_router__WEBPACK_IMPORTED_MODULE_4___default().events.on(\"routeChangeStart\", hideContent);\n        // on route change complete - run auth check\n        next_router__WEBPACK_IMPORTED_MODULE_4___default().events.on(\"routeChangeComplete\", authCheck);\n        // unsubscribe from events in useEffect return function\n        return ()=>{\n            next_router__WEBPACK_IMPORTED_MODULE_4___default().events.off(\"routeChangeStart\", hideContent);\n            next_router__WEBPACK_IMPORTED_MODULE_4___default().events.off(\"routeChangeComplete\", authCheck);\n        };\n        console.log(\"data\");\n    // eslint-disable-next-line react-hooks/exhaustive-deps\n    }, []);\n    function authCheck(url) {\n        const tokens = localStorage.getItem(\"jwt\");\n        // redirect to login page if accessing a private page and not logged in\n        setUser(tokens);\n        const publicPaths = [\n            \"/\",\n            \"/\"\n        ];\n        const path = url.split(\"?\")[0];\n        if (!tokens && !publicPaths.includes(path)) {\n            setAuthorized(false);\n            next_router__WEBPACK_IMPORTED_MODULE_4___default().push({\n                pathname: \"/\",\n                query: {\n                    returnUrl: (next_router__WEBPACK_IMPORTED_MODULE_4___default().asPath)\n                }\n            });\n        } else {\n            setAuthorized(true);\n        }\n    }\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: authorized && /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {\n            ...pageProps\n        }, void 0, false, {\n            fileName: \"D:\\\\gupta_all_folders\\\\next.js\\\\nextApiProject\\\\api-project\\\\pages\\\\_app.js\",\n            lineNumber: 50,\n            columnNumber: 27\n        }, this)\n    }, void 0, false);\n}\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyApp);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9fYXBwLmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFBa0Q7QUFDZjtBQUNKO0FBQ0U7QUFDQTtBQUNDO0FBRWxDLFNBQVNJLE1BQU0sRUFBRUMsVUFBUyxFQUFFQyxVQUFTLEVBQUUsRUFBRTtJQUN2QyxNQUFNLENBQUNDLE1BQU1DLFFBQVEsR0FBR1AsK0NBQVFBLENBQUMsSUFBSTtJQUNyQyxNQUFNLENBQUNRLFlBQVlDLGNBQWMsR0FBR1QsK0NBQVFBLENBQUMsS0FBSztJQUVsREUsZ0RBQVNBLENBQUMsSUFBTTtRQUNkLG1DQUFtQztRQUNuQ1EsVUFBVVQsMkRBQWE7UUFFdkIsMkVBQTJFO1FBQzNFLE1BQU1XLGNBQWMsSUFBTUgsY0FBYyxLQUFLO1FBQzdDUiw0REFBZ0IsQ0FBQyxvQkFBb0JXO1FBRXJDLDRDQUE0QztRQUM1Q1gsNERBQWdCLENBQUMsdUJBQXVCUztRQUV4Qyx1REFBdUQ7UUFDdkQsT0FBTyxJQUFNO1lBQ1hULDZEQUFpQixDQUFDLG9CQUFvQlc7WUFDdENYLDZEQUFpQixDQUFDLHVCQUF1QlM7UUFDM0M7UUFDQU0sUUFBUUMsR0FBRyxDQUFDO0lBRVosdURBQXVEO0lBQ3pELEdBQUcsRUFBRTtJQUVMLFNBQVNQLFVBQVVRLEdBQUcsRUFBRTtRQUN0QixNQUFNQyxTQUFTQyxhQUFhQyxPQUFPLENBQUM7UUFDcEMsdUVBQXVFO1FBQ3ZFZCxRQUFRWTtRQUNSLE1BQU1HLGNBQWM7WUFBQztZQUFLO1NBQUk7UUFDOUIsTUFBTUMsT0FBT0wsSUFBSU0sS0FBSyxDQUFDLElBQUksQ0FBQyxFQUFFO1FBQzlCLElBQUksQ0FBQ0wsVUFBVSxDQUFDRyxZQUFZRyxRQUFRLENBQUNGLE9BQU87WUFDMUNkLGNBQWMsS0FBSztZQUNuQlIsdURBQVcsQ0FBQztnQkFDVjBCLFVBQVU7Z0JBQ1ZDLE9BQU87b0JBQUVDLFdBQVc1QiwyREFBYTtnQkFBQztZQUNwQztRQUNGLE9BQU87WUFDTFEsY0FBYyxJQUFJO1FBQ3BCLENBQUM7SUFDSDtJQUVBLHFCQUFPO2tCQUFHRCw0QkFBYyw4REFBQ0o7WUFBVyxHQUFHQyxTQUFTOzs7Ozs7O0FBQ2xEO0FBQ0EsaUVBQWVGLEtBQUtBLEVBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9hcGktcHJvamVjdC8uL3BhZ2VzL19hcHAuanM/ZTBhZCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBTZXNzaW9uUHJvdmlkZXIgfSBmcm9tIFwibmV4dC1hdXRoL3JlYWN0XCI7XG5pbXBvcnQgXCIuLi9zdHlsZXMvSG9tZS5tb2R1bGUuY3NzXCI7XG5pbXBvcnQgXCIuLi9zdHlsZXMvZ2xvYmFscy5jc3NcIjtcbmltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgUm91dGVyIGZyb20gXCJuZXh0L3JvdXRlclwiO1xuaW1wb3J0IHsgdXNlRWZmZWN0IH0gZnJvbSBcInJlYWN0XCI7XG5cbmZ1bmN0aW9uIE15QXBwKHsgQ29tcG9uZW50LCBwYWdlUHJvcHMgfSkge1xuICBjb25zdCBbdXNlciwgc2V0VXNlcl0gPSB1c2VTdGF0ZShudWxsKTtcbiAgY29uc3QgW2F1dGhvcml6ZWQsIHNldEF1dGhvcml6ZWRdID0gdXNlU3RhdGUoZmFsc2UpO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgLy8gb24gaW5pdGlhbCBsb2FkIC0gcnVuIGF1dGggY2hlY2tcbiAgICBhdXRoQ2hlY2soUm91dGVyLmFzUGF0aCk7XG5cbiAgICAvLyBvbiByb3V0ZSBjaGFuZ2Ugc3RhcnQgLSBoaWRlIHBhZ2UgY29udGVudCBieSBzZXR0aW5nIGF1dGhvcml6ZWQgdG8gZmFsc2VcbiAgICBjb25zdCBoaWRlQ29udGVudCA9ICgpID0+IHNldEF1dGhvcml6ZWQoZmFsc2UpO1xuICAgIFJvdXRlci5ldmVudHMub24oXCJyb3V0ZUNoYW5nZVN0YXJ0XCIsIGhpZGVDb250ZW50KTtcblxuICAgIC8vIG9uIHJvdXRlIGNoYW5nZSBjb21wbGV0ZSAtIHJ1biBhdXRoIGNoZWNrXG4gICAgUm91dGVyLmV2ZW50cy5vbihcInJvdXRlQ2hhbmdlQ29tcGxldGVcIiwgYXV0aENoZWNrKTtcblxuICAgIC8vIHVuc3Vic2NyaWJlIGZyb20gZXZlbnRzIGluIHVzZUVmZmVjdCByZXR1cm4gZnVuY3Rpb25cbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgUm91dGVyLmV2ZW50cy5vZmYoXCJyb3V0ZUNoYW5nZVN0YXJ0XCIsIGhpZGVDb250ZW50KTtcbiAgICAgIFJvdXRlci5ldmVudHMub2ZmKFwicm91dGVDaGFuZ2VDb21wbGV0ZVwiLCBhdXRoQ2hlY2spO1xuICAgIH07XG4gICAgY29uc29sZS5sb2coXCJkYXRhXCIsIClcblxuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSByZWFjdC1ob29rcy9leGhhdXN0aXZlLWRlcHNcbiAgfSwgW10pO1xuXG4gIGZ1bmN0aW9uIGF1dGhDaGVjayh1cmwpIHtcbiAgICBjb25zdCB0b2tlbnMgPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImp3dFwiKTtcbiAgICAvLyByZWRpcmVjdCB0byBsb2dpbiBwYWdlIGlmIGFjY2Vzc2luZyBhIHByaXZhdGUgcGFnZSBhbmQgbm90IGxvZ2dlZCBpblxuICAgIHNldFVzZXIodG9rZW5zKTtcbiAgICBjb25zdCBwdWJsaWNQYXRocyA9IFtcIi9cIiwgXCIvXCJdO1xuICAgIGNvbnN0IHBhdGggPSB1cmwuc3BsaXQoXCI/XCIpWzBdO1xuICAgIGlmICghdG9rZW5zICYmICFwdWJsaWNQYXRocy5pbmNsdWRlcyhwYXRoKSkge1xuICAgICAgc2V0QXV0aG9yaXplZChmYWxzZSk7XG4gICAgICBSb3V0ZXIucHVzaCh7XG4gICAgICAgIHBhdGhuYW1lOiBcIi9cIixcbiAgICAgICAgcXVlcnk6IHsgcmV0dXJuVXJsOiBSb3V0ZXIuYXNQYXRoIH0sXG4gICAgICB9KTtcbiAgICB9IGVsc2Uge1xuICAgICAgc2V0QXV0aG9yaXplZCh0cnVlKTtcbiAgICB9XG4gIH1cblxuICByZXR1cm4gPD57YXV0aG9yaXplZCAmJiA8Q29tcG9uZW50IHsuLi5wYWdlUHJvcHN9IC8+fTwvPjtcbn1cbmV4cG9ydCBkZWZhdWx0IE15QXBwO1xuIl0sIm5hbWVzIjpbIlNlc3Npb25Qcm92aWRlciIsInVzZVN0YXRlIiwiUm91dGVyIiwidXNlRWZmZWN0IiwiTXlBcHAiLCJDb21wb25lbnQiLCJwYWdlUHJvcHMiLCJ1c2VyIiwic2V0VXNlciIsImF1dGhvcml6ZWQiLCJzZXRBdXRob3JpemVkIiwiYXV0aENoZWNrIiwiYXNQYXRoIiwiaGlkZUNvbnRlbnQiLCJldmVudHMiLCJvbiIsIm9mZiIsImNvbnNvbGUiLCJsb2ciLCJ1cmwiLCJ0b2tlbnMiLCJsb2NhbFN0b3JhZ2UiLCJnZXRJdGVtIiwicHVibGljUGF0aHMiLCJwYXRoIiwic3BsaXQiLCJpbmNsdWRlcyIsInB1c2giLCJwYXRobmFtZSIsInF1ZXJ5IiwicmV0dXJuVXJsIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/_app.js\n");

/***/ }),

/***/ "./styles/globals.css":
/*!****************************!*\
  !*** ./styles/globals.css ***!
  \****************************/
/***/ (() => {



/***/ }),

/***/ "next-auth/react":
/*!**********************************!*\
  !*** external "next-auth/react" ***!
  \**********************************/
/***/ ((module) => {

"use strict";
module.exports = require("next-auth/react");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/_app.js"));
module.exports = __webpack_exports__;

})();